<div class="row headerbar">
    <img class="headerimg"
         src="bilder/index/headerpicture2.jpg"
         alt="Headerbild">
    <div class="searchboxprnt row">
        <div class="searchbox">
            <div class=" ctr">
                <form action="">
                    <div class="ta-ctr quicksearchheader">
                        Schnellsuche
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-4 nopad-r">
                            <div class="quicksearchinput">
                                <i class="fa-thin fa-magnifying-glass"></i>
								<label for="unternehmen"></label><input type="text" id="unternehmen" autocomplete="off">
                            </div>
                            <div id="unternehmenliste"></div>
                            <small>Name des Unternehmens</small>
                        </div>
                        <div class="col-12 col-md-4 nopad-r">
                            <div class="quicksearchinput">
                                <i class="fa-thin fa-user-headset"></i>
								<label for="jobtitel"></label><input type="text" id="jobtitel" autocomplete="off">
                            </div>
                            <div id="jobliste"></div>
                            <small>Jobtitel</small>
                        </div>

                        <div class="col-12 col-md-3 nopad-r">
                            <div class="quicksearchinput location">
                                <i class="fa-thin fa-location-dot"></i>
                                <input type="text" id="PLZ" autocomplete="off">
                            </div>
                            <div ID="OrtsListe"></div>
                            <label for="PLZ"><small>Ort oder Postleitzahl</small></label>
                        </div>
                        <div class="col-12 col-md-1 lg-1 resp-nopad-r">
                            <div class="">
                                <button type="submit"
                                        class="seachbutton">
                                    <i class="fa-light fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>