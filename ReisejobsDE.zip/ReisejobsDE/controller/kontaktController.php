<?php

namespace controller;


class kontaktController extends Controller
{




    public function verarbeiteDaten()
    {
        $strFileName = "kontaktView.php";
        include "view/layout.php";
    }
}