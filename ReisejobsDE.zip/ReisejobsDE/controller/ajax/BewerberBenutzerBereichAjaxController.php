<?php

namespace controller\ajax;

use controller\Controller;

class BewerberBenutzerBereichAjaxController extends Controller
{

    /**
     * @inheritDoc
     */
    public function verarbeiteDaten()
    {
        // TODO: Implement verarbeiteDaten() method.
    }
}