<?php

namespace model\enum;

class UserTypeEnum
{
    public const BEWERBER = "Bewerber";
    public const UNTERNEHMEN = "Unternehmen";
}