<?php

namespace model\enum;

class PasswordEnum
{
    public const SMTP = "smtp://testmailmarcob@gmail.com:Voidyz_882@smtp.gmail.com:587";
}